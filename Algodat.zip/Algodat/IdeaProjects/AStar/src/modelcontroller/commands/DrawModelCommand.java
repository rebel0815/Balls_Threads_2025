package modelcontroller.commands;


public abstract class DrawModelCommand {

	public DrawModelCommand() {
	}
	
}
