package modelcontroller.commands;

public class DrawModelResetCommand extends DrawModelCommand {

}
