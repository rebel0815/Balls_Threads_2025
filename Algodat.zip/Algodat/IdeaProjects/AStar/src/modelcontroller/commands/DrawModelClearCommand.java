package modelcontroller.commands;

public class DrawModelClearCommand extends DrawModelCommand {

}
