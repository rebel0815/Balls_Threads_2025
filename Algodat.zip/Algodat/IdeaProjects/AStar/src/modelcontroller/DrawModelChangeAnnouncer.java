package modelcontroller;

public interface DrawModelChangeAnnouncer {

	public void registerChangeListener(DrawModelChangeListener x);
	
}
