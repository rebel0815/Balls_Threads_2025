package astar;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import modelcontroller.DrawModel;
import modelcontroller.commands.DrawModelResetCommand;
import shapes.Shape;
import shapes.ShapeLine;
import shapes.ShapePoint;


public class AStar {

	public static void calculate(List<ShapeLine> lineList, Set<ShapePoint> pointSet, ShapePoint startPoint, ShapePoint endPoint) {

		Set<ShapePoint> closedList = new HashSet<ShapePoint>();
		Set<ShapePoint> openList = new HashSet<ShapePoint>();

		////////////////////////////////////////////////////////

		// Anfangszustand herstellen
		startPoint.setRoute(null);
		startPoint.setHeuristics(startPoint.distance(endPoint));
		openList.add(startPoint);
		// solange die openList nicht leer ist und der Endpunkt nicht in der closed List
		while ( !openList.isEmpty() && !closedList.contains(endPoint) ) {
			// Knoten expandieren den minimalen Knoten aus der openlist finden
			ShapePoint expandPoint = findMinimalPoint(openList);

			openList.remove(expandPoint);
			closedList.add(expandPoint);

			for (Shape x : closedList) {
				colorPath(expandPoint, Color.MAGENTA);
				x.blink();
				x.setColor(Color.MAGENTA);
			}

			// alle Nachfolger (workpoints) finden
			for (ShapeLine currLine : lineList) {
				if (currLine.hasPoint(expandPoint)) {
					ShapePoint workPoint = currLine.traverse(expandPoint);
					if (closedList.contains(workPoint)) {
						// 1. workPoint ist in der closed list
						// nichts zu tun
						continue;
					}
					double newHeuristic = expandPoint.getHeuristics() + currLine.length();

					// 2. workPoint ist in der open list
					if (openList.contains(workPoint)) {
						// alteHeuristik mit neuer neueHeuristik (Rueckweg ueber expandPoint) vergleichen
						if (workPoint.getHeuristics() > newHeuristic) {
							//    wenn alte Heuristik besser
							//        tu nichts
							//    wenn neue Heuristik besser
							workPoint.setHeuristics(newHeuristic);
							workPoint.setRoute(currLine);
							//        setze neuen Rueckweg
							//        setze neue Heuristik
						}
					} else {
						// 3. workPoint ist in der unknown list
						workPoint.setHeuristics(newHeuristic);
						workPoint.setRoute(currLine);
						// setze Rueckweg von workPoint
						openList.add(workPoint);
					}
				}
			}
		}
		// setze Heuristik fuer workPoint
		// gib workpoint in die openlist
		// nimm den expandPoint aus der openList raus
		// und tu ihn in die close list
		if (closedList.contains(endPoint)) {
			colorPath(endPoint, Color.GREEN);
		}
		else {
			System.out.println("Keine Lösung möglich");
		}
		// wenn Lösung gefunden: Anzeigen
		// sonst keine Loesung moeglich
		////////////////////////////////////////////////////////

		//// sinnloses AStern zum Ausprobieren ////////////////////////////////////////////////////
		//for (Shape x : lineList) {
		//x.blink();
		//x.setColor(Color.MAGENTA);
		//}
		////////////////////////////////////////////////////////

	}

	private static void savesetColor(ShapePoint point, ShapePoint startPoint, ShapePoint endPoint, Color color) {
		if ( ! point.equals(startPoint) && ! point.equals(endPoint) ) point.setColor(color);

	}


	private static void colorPath(ShapePoint end, Color c) {
		if (end.getRoute() != null) {
			end.getRoute().setColor(c);
			colorPath(end.getRoute().traverse(end), c);
		}
	}


	private static double pathLength(ShapePoint end) {
		if (end.getRoute() == null) return 0;
		else return end.getRoute().length() + pathLength(end.getRoute().traverse(end));
	}


	private static ShapePoint findMinimalPoint(Set<ShapePoint> openList) {
		ShapePoint minimalPoint = null;
		for (ShapePoint x : openList) {
			if (x.getHeuristics() != 0.0) {
				if  (minimalPoint == null) minimalPoint = x;
				else if (minimalPoint.getHeuristics() > x.getHeuristics()) minimalPoint = x;
			}
		}
		return minimalPoint;
	}

}