package InOut.src.inout;

public class InOutException extends Exception {

	private static final long serialVersionUID = 1L;

}
