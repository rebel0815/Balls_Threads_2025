package schiff;

public class Frachtschiff extends schiff {
    // TODO Fields of Frachtschiff

    public Frachtschiff() {
        // TODO Initialization of fields of Frachtschiff
    }

    // TODO Implement body of Frachtschiff
}
