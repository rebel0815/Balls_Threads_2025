package schiff;

import schiff.schiff;

public class Passagierschiff extends schiff {
    // TODO Fields of Passagierschiff

    public Passagierschiff() {
        // TODO Initialization of fields of Passagierschiff
    }

    // TODO Implement body of Passagierschiff
}
