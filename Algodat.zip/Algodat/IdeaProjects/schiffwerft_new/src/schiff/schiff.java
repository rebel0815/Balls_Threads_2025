package schiff;

public class schiff {
    // TODO Fields of schiff

    public schiff() {
        // TODO Initialization of fields of schiff
    }

    // TODO Implement body of schiff
}
