import InOut.src.inout.InOut;
import Werft.Werft;
import schiff.Passagierschiff;
import schiff.schiff;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        // Die Schiffswerft
        Werft meineWerft = new Werft();
        try {
        // TODO Monat für Monat
        while (true) {
            // TODO Schiffe fahren herum und produzieren Geld
            // TODO Schiffe die verostet sind sinken -> Kosten
            // TODO User entscheidung
            int choice = 0;
                    choice = InOut.readMenu("Was wollen Sie tun?",
                    "Neues Passagierschiff" +
                    "Neues Frachtschiff" +
                    "Neues Tankschiff" +
                    "Schiff streichen" +
                    "Schiff verschrotten" +
                    "Pause" +
                    "Spiel benden");
                switch (choice) {
                    case 1: // TODO Neues Passagierschiff
                    {
                        schiff x = new Passagierschiff();
                        meineWerft.bezahlt(x);
                        meineWerft.uebernimmt(x);
                    }
                        break;
                    case 2:// TODO Neues Frachtschiff
                    {
                        schiff x = new Frachtschiff
                    }
                        break;
                    case 3:// TODO Neuer Tanker
                        break;
                    case 4:// TODO Streichen
                        break;
                    case 5:// TODO Verschrotten
                        break;
                    case 6:// TODO Pause
                        break;
                    case 7:// TODO Spiel beenden
                        break;

    }
}}
