package Werft;

public class Werft {
    // TODO Fields of Werft

    public Werft() {
        // TODO Initialization of fields of Werft
    }

    // TODO Implement body of Werft
}
