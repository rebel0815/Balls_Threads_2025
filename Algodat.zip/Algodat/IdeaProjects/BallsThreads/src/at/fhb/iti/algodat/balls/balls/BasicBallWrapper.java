package at.fhb.iti.algodat.balls.balls;

import at.fhb.iti.algodat.balls.BallRectangle;
import at.fhb.iti.algodat.balls.grafics.BallsPanel;

public class BasicBallWrapper extends BasicBall {
    public BasicBallWrapper(BallsPanel ballsPanel) {
        super(ballsPanel);
    }

    public boolean isTouchingPublic(BallRectangle rectangle) {
        return isTouching(rectangle);
    }
}