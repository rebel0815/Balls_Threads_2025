package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBallRectangle;


public class BallRectangle extends BasicBallRectangle {
	private int tickets;
	public BallRectangle(int d, int e, int f, int g) {
		super(d,e,f,g);
		tickets = 3;
	}

	public synchronized void occupy() {
		// log();
		while (tickets <= 0) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}
		assert tickets > 0;
		tickets--;

	}

	public synchronized void free() {
		tickets++;
		notify();
	}

	public void log() {
		System.out.println("Tickets: " + tickets);
	}
}
