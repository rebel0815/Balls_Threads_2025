package definitions;

public class Definitions {
    public static final double ANFANGSKAPITAL = 500; // in Mio EUR
    public static final double FRACHTSCHIFFPREIS = 30 ;
    public static final double PASSAGIERSCHIFFPREIS = 150;
    public static final double TANKSCHIFFPREIS = 70;

    public static final double FRACHTSCHIFFGEWINN = 0.2;
    public static final double PASSAGIERSCHIFFGEWINN = 1.0;
    public static final double TANKSCHIFFGEWINN = 0.5;
    public static final double MINDESTINTAKTESCHIFFSHAUT = 0.25;
    public static final double BERGUNGSFAKTOR = 5.0;
    public static final double ABNUTZUNGSFAKTOR = 0.92;


    public static final double STREICHABNUTZUNG = 0.05;
    public static final double FRACHTSCHIFFANSTRICH = 1;
    public static final double TANKSCHIFFANSTRICH = 3;
    public static final double PASSAGIERSCHIFFANSTRICH = 5;
}
