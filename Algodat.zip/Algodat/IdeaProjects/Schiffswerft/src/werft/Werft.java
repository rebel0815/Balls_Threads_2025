package werft;

import definitions.Definitions;
import inout.InOut;
import schiffe.Schiff;
import spiel.KonkursException;

import java.util.LinkedList;
import java.util.List;

public class Werft {

    private Kassa dieKassa = new  Kassa(Definitions.ANFANGSKAPITAL);
    private List<Schiff> dieSchiffe; // = new LinkedList<Schiff>();


    public Werft() {
        // TODO Constructor of Werft
        Kassa dieKassa = new Kassa(Definitions.ANFANGSKAPITAL);
        dieSchiffe = new LinkedList<Schiff>();
    }

    public void arbeitetEinenMonat() throws KonkursException  {
        // TODO Werft arbeitet einen Monat
        schadhafteSchiffeSinken();
        schiffeFahrenHerumUndGenerierenGewinn();
    }

    private void schiffeFahrenHerumUndGenerierenGewinn() {
        for (Schiff x: dieSchiffe) {
            x.nutztSichAbEinenMonat();
            dieKassa.nimmtEin(x.monatsGewinn());
        }
    }

    private void schadhafteSchiffeSinken() throws KonkursException {
        List<Schiff> schadhafteSchiffe = new LinkedList<Schiff>();

        for (Schiff x: dieSchiffe) {
            if (x.schadHaft()) schadhafteSchiffe.add(x);
        }
        for (Schiff x: schadhafteSchiffe){
            dieKassa.zahltAus(x.schadensPreis());
        }
        dieSchiffe.removeAll(schadhafteSchiffe);
    }


    public void zustandAusgeben() {
        // TODO Werft Zustand ausgeben
        InOut.printString("Zustand der Kassa:");
        dieKassa.zustandAusgeben();
        InOut.printString("Es gibt folgende Schiffe:");
        for (Schiff x: dieSchiffe) {
            x.zustandAusgeben();
        }


    }

    // TODO Weitere Methoden der Werft
    public void bezahlt(double preis) throws KonkursException {
        // TODO in werft.Werft
        dieKassa.zahltAus(preis);
    }
    public void uebernimmt(Schiff x){
        //TODO in werft.Werft
        dieSchiffe.add(x);
    }


    public void schiffStreichen(int schiffNummer) throws KonkursException {
        for (Schiff schiff: dieSchiffe) {
            if (schiff.getSchiffsNummer() == schiffNummer){
                schiff.streichtSchiff();
                dieKassa.zahltAus(schiff.anstrichPreis());
                break;
            }
        }
    }

    public void schiffVerschrotten(int schiffNummer) throws KonkursException {
        for (Schiff schiff: dieSchiffe) {
            if (schiff.getSchiffsNummer() == schiffNummer) {
                schiff.streichtSchiff();
                dieKassa.zahltAus(schiff.verschrottenPreis());
                break;
            }
        }
        dieSchiffe.remove(schiffNummer);
    }
}
