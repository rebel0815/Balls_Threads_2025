package werft;

import definitions.Definitions;
import inout.InOut;
import spiel.KonkursException;


public class Kassa {
    // TODO Fields of Kassa
    private double kassaStand;

    public Kassa(double anfangskapital) {
        // TODO Initialization of fields of Kassa
        kassaStand = Definitions.ANFANGSKAPITAL;
    }

    public void zahltAus(double preis) throws KonkursException {
        if (preis > kassaStand) throw new KonkursException();
        kassaStand = kassaStand - preis;
    }
    public void zustandAusgeben() {
        InOut.printString("Kassastand:" + kassaStand);
    }

    public void nimmtEin(double b) {
        kassaStand = kassaStand + b;
    }
    // TODO Implement body of Kassa
}
