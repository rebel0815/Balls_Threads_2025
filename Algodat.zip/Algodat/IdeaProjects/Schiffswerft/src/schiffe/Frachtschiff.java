package schiffe;


import definitions.Definitions;

public class Frachtschiff extends Schiff {

    // TODO Fields of Frachtschiff

    public Frachtschiff (){
        //TODO Initialization of fields of Frachtschiff
    }


    public double preis() {
        return Definitions.FRACHTSCHIFFPREIS;
    }

    protected String schiffsArt() {
        return "Frachtschiff";
    }

    public double monatsGewinn() {
        return Definitions.FRACHTSCHIFFGEWINN;
    }

    public double anstrichPreis() {return Definitions.FRACHTSCHIFFANSTRICH;}

    public double verschrottenPreis() {
        return Definitions.FRACHTSCHIFFPREIS * 0.1;
    }

    // TODO Implement body of Frachtschiff
}
