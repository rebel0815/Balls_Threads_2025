package schiffe;

import definitions.Definitions;
import inout.InOut;

public abstract class Schiff {
    // TODO Fields of Schiff
    private int schiffsNummer;
    private int anstrichAnzahl;
    private double intakteSchiffsHaut;
    private static int naechsteFreieSchiffsNummer = 1;


    public Schiff() {
    this.schiffsNummer = naechsteFreieSchiffsNummer++;
    this.intakteSchiffsHaut = 1;
    this.anstrichAnzahl = 0;

    }
    abstract public double preis();

    public void zustandAusgeben() {
        InOut.printString(
                "Schiff " + schiffsNummer +
                        " ist ein " + schiffsArt() +
                        ", es sind " + intakteSchiffsHaut * 100 + "% Schiffshaut intakt"
        );
    }

    protected abstract String schiffsArt();

    public abstract double monatsGewinn();

    public boolean schadHaft() {
        return intakteSchiffsHaut < Definitions.MINDESTINTAKTESCHIFFSHAUT;
    }

    public double schadensPreis() {
        return Definitions.BERGUNGSFAKTOR * preis();
    }

    public void nutztSichAbEinenMonat() {
        intakteSchiffsHaut = intakteSchiffsHaut * Definitions.ABNUTZUNGSFAKTOR;
    }

    public void streichtSchiff() {
            this.intakteSchiffsHaut = 1 - (anstrichAnzahl * Definitions.STREICHABNUTZUNG);
            this.anstrichAnzahl++;


    }

    // getter
    public int getSchiffsNummer() {return this.schiffsNummer;}

    public abstract double anstrichPreis();

    public abstract double verschrottenPreis();


    // TODO Implement body of Schiff

}
