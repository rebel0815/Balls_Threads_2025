package schiffe;

import definitions.Definitions;

public class Tankschiff extends Schiff {

    public double preis() {

        return Definitions.TANKSCHIFFPREIS;
    }

    protected String schiffsArt() {
        return "Tankschiff";
    }

    public double monatsGewinn() {
        return Definitions.TANKSCHIFFGEWINN;
    }

    public double anstrichPreis() {
        return Definitions.TANKSCHIFFANSTRICH;
    }

    public double verschrottenPreis() {
        return Definitions.TANKSCHIFFPREIS * 0.1;
    }
}
