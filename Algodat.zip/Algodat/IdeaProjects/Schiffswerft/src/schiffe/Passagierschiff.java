package schiffe;

import definitions.Definitions;

public class Passagierschiff extends Schiff {

    public Passagierschiff() {
        // TODO Initialization of fields of Passagierschiff
    }

    public double preis() {
        // TODO implement preis in schiffe.Passagierschiff
        return Definitions.PASSAGIERSCHIFFPREIS;
    }

    protected String schiffsArt() {
        return "Passagierschiff";
    }

    public double monatsGewinn() {
        return Definitions.PASSAGIERSCHIFFGEWINN;
    }

    public double anstrichPreis() {
        return Definitions.PASSAGIERSCHIFFANSTRICH;
    }

    public double verschrottenPreis() {
        return Definitions.PASSAGIERSCHIFFPREIS * 0.1;
    }

    // TODO Implement body of Passagierschiff
}
