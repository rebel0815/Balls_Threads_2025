package spiel;

public class SpielendeException extends Throwable {

}
