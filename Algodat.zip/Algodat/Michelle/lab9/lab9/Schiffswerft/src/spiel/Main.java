package spiel;
import inout.InOut;
import inout.InOutException;
import schiffe.Frachtschiff;
import schiffe.Passagierschiff;
import schiffe.Schiff;
import schiffe.Tankschiff;
import spiel.SpielendeException;
import werft.Werft;


public class Main {
    public static void main(String[] args) {
        Werft dieWerft = new Werft();
        // Ablauf Monat für Monat
        try {
            while (true) {
                // Werft arbeitet einen Monat
                dieWerft.arbeitetEinenMonat();
                // Ausgabe: Zustand der Werft
                dieWerft.zustandAusgeben();
                // Auswahl
                int auswahl = InOut.readMenu("Was ist zu tun?",
                        "Ein Frachtschiff bauen@" +
                                "Ein Passagierschiff bauen@" +
                                "Ein Tankschiff bauen@" +
                                "Ein Schiff streichen@" +
                                "Ein Schiff verschrotten@" +
                                "Nichts tun@" +
                                "Spielende");
                switch (auswahl) {
                    case 1 ->// ein Frachtschiff bauen
                    {
                        Schiff x = new Frachtschiff();
                        dieWerft.bezahlt(x.preis());
                        dieWerft.uebernimmt(x);
                    }
                    case 2 -> // ein Passagierschiff bauen
                    {
                        Schiff x = new Passagierschiff();
                        dieWerft.bezahlt(x.preis());
                        dieWerft.uebernimmt(x);
                    }
                    case 3 -> // ein Tankschiff bauen
                    {
                        Schiff x = new Tankschiff();
                        dieWerft.bezahlt(x.preis());
                        dieWerft.uebernimmt(x);
                    }
                    case 4 -> // ein Schiff streichen
                    {
                        InOut.printString("Welches Schiff soll gestrichen werden?");
                        dieWerft.zeigtRost();
                        while (true) {
                            int schiffsNr = InOut.readInt("Schiffsnummer eingeben: ");
                            if(dieWerft.schiffExists(schiffsNr)){
                                dieWerft.streichtSchiff(schiffsNr);
                                break;
                            }else{
                              InOut.printString("Schiff existiert nicht! Andere Schiffsnummer eingeben!");
                            }
                        }
                    }
                    case 5 -> // ein Schiff verschrotten
                    {
                        InOut.printString("Welches Schiff soll verschrottet werden?");
                        while(true){
                            int schiffsNr = InOut.readInt("Schiffsnummer eingeben: ");
                            if(dieWerft.schiffExists(schiffsNr)){
                                dieWerft.schrottetSchiff(schiffsNr);
                                break;
                            }else{
                                InOut.printString("Schiff existiert nicht! Andere Schiffsnummer eingeben!");
                            }
                        }
                    }
                    case 6 -> // Pause
                    {
                        InOut.printString("Pause");
                    }
                    case 7 -> // Spielende
                    {
                        throw new SpielendeException();
                    }
                    default -> {
                        InOut.printString("Unknown menu entry!");
                    }
                }
            }
        } catch (InOutException x) {
            InOut.printString("Fehleingabe, Spielende");
        } catch (SpielendeException x) {
            InOut.printString("Spielende");
        } catch (KonkursException x) {
         InOut.printString("Spielende wegen Konkurs");
        }
    }
}