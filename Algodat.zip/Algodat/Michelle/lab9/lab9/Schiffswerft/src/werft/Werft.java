package werft;
import inout.InOut;
import definitions.Definitions;
import java.util.ArrayList;
import java.util.List;
import schiffe.Schiff;
import spiel.KonkursException;
import java.util.LinkedList;
public class Werft {
    Kassa dieKassa;
    List<Schiff> dieSchiffe;
    public Werft() {
        dieKassa = new Kassa(Definitions.ANFANGSKAPITAL);
        dieSchiffe = new LinkedList<Schiff>();
    }
    public void arbeitetEinenMonat()  throws KonkursException {
        schadhafteSchiffeSinken();
        schiffeFahrenHerumUndGenerienGewinn();
    }

    private void schadhafteSchiffeSinken() throws KonkursException {
        List<Schiff> schadhafteSchiffe = new LinkedList<Schiff>();
        for (Schiff x: dieSchiffe) {
            if (x.schadhaft()) schadhafteSchiffe.add(x);
        }
        for (Schiff x: schadhafteSchiffe) {
            dieKassa.zahltAus(x.schadensPreis());
        }
        dieSchiffe.removeAll(schadhafteSchiffe);
    }
    private void schiffeFahrenHerumUndGenerienGewinn() {
        for (Schiff x: dieSchiffe) {
            x.nutztSichAbMonatlich();
            dieKassa.nimmtEin(x.monatsGewinn());
        }
    }

    public void bezahlt(double preis) throws KonkursException {
        dieKassa.zahltAus(preis);
    }

    public void uebernimmt(Schiff x) {
        dieSchiffe.add(x);
    }

    public void streichtSchiff(int schiffsNr) {
        for (Schiff x: dieSchiffe){
            if(x.getNummer() == schiffsNr) {
                x.neuerAnstrich();
                dieKassa.bezahltAnstrich(x);
                InOut.printString(x.getNummer() + " wird neu gestrichen.");
            }
        }
    }

    public void zeigtRost() {
        for(Schiff x: dieSchiffe) {
            InOut.printString(x.getNummer() + ": " + x.schiffsArt() + " mit " + x.getStatusSchiffshaut() * 100 + "% Schiffshaut intakt");
        }
    }

    public boolean schiffExists(int schiffNr) {
        for(Schiff x: dieSchiffe) {
            if(x.getNummer() == schiffNr) {
                return true;
            }
        }
        return false;
    }

    public void schrottetSchiff(int schiffNr) throws KonkursException {
        Schiff schrottSchiff = null;
        for (Schiff x: dieSchiffe) {
            if(x.getNummer() == schiffNr) {
                schrottSchiff = x;
            }
        }
        dieKassa.zahltAus(schrottSchiff.SchrottPreis());
        dieSchiffe.remove(schrottSchiff);
    }

    public void zustandAusgeben() {
        InOut.printString("Zustand der Kassa: ");
        dieKassa.zustandAusgeben();
        InOut.printString("Es gibt folgende Schiffe: ");
        for (Schiff x: dieSchiffe) {
            x.zustandAusgabe();
        }
    }

}
