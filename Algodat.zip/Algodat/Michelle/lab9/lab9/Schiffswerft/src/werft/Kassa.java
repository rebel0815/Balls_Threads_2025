package werft;
import definitions.Definitions;
import inout.InOut;
import schiffe.Frachtschiff;
import schiffe.Passagierschiff;
import schiffe.Schiff;
import schiffe.Tankschiff;
import spiel.KonkursException;
public class Kassa {
    private double kassastand;
    public Kassa(double anfangskapital) {
        kassastand = anfangskapital;
    }
    public void zahltAus(double preis) throws KonkursException {
        if (preis > kassastand) {
            throw new KonkursException();
        }
        kassastand = kassastand - preis;
    }

    public void zustandAusgeben() {
        InOut.printString("Der Kassastand ist " + kassastand);
    }

    public void nimmtEin(double betrag) {
        kassastand +=betrag;
    }

    public void bezahltAnstrich(Schiff x) {
        if(x instanceof Frachtschiff) kassastand -= Definitions.FRACHTSCHIFFANSTRICHSPREIS;
        if(x instanceof Tankschiff) kassastand -= Definitions.TANKSCHIFFANSTRICHSPREIS;
        if(x instanceof Passagierschiff) kassastand -= Definitions.PASSAGIERSCHIFFANSTRICHSPREIS;
    }


}
