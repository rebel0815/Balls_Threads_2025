package definitions;

public class Definitions {
    public static final double ANFANGSKAPITAL = 500; // in Mio EUR
    public static final double FRACHTSCHIFFPREIS = 30 ;
    public static final double PASSAGIERSCHIFFPREIS = 200;
    public static final double TANKSCHIFFPREIS = 50;
    public static final double TANKSCHIFFMONATSGEWINN = 0.5;
    public static final double PASSAGIERSCHIFFMONATSGEWINN = 0.25;
    public static final double FRACHTSCHIFFGEWINN = 1;
    public static final double MINDESTINTAKTSCHIFFSHAUT = 0.25;
    public static final double  ABNUTZUNGSFAKTOR = 0.92;
    public static final double PASSAGIERSCHIFFANSTRICHSPREIS = 10;
    public static final double TANKSCHIFFANSTRICHSPREIS = 5;
    public static final double FRACHTSCHIFFANSTRICHSPREIS = 1;
}

