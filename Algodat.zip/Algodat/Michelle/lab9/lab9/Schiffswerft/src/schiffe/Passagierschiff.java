package schiffe;
import definitions.Definitions;
public class Passagierschiff extends Schiff{
    public Passagierschiff() {}

    public double preis() {
        return Definitions.PASSAGIERSCHIFFPREIS;
    }

    public String schiffsArt() {
        return "Passagierschiff";
    }

    public double monatsGewinn() {
        return Definitions.PASSAGIERSCHIFFMONATSGEWINN;
    }
}
