package schiffe;
import definitions.Definitions;


public class Tankschiff extends Schiff {
    public Tankschiff() {}

    public double preis() {
        return Definitions.TANKSCHIFFPREIS;
    }

    public String schiffsArt() {
        return "Tankschiff";
    }

    public double monatsGewinn() {
        return Definitions.TANKSCHIFFMONATSGEWINN;
    }

}
