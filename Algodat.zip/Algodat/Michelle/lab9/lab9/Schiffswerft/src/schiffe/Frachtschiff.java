package schiffe;
import definitions.Definitions;

public class Frachtschiff extends Schiff {

    public Frachtschiff() {}

    public double preis() {
        return Definitions.FRACHTSCHIFFPREIS;
    }
    public String schiffsArt() {
        return "Frachtschiff";
    }

    public double monatsGewinn() {
        return Definitions.FRACHTSCHIFFGEWINN;
    }
}
