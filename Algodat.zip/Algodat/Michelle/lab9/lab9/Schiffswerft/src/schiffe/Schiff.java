package schiffe;
import definitions.Definitions;
import inout.InOut;

public abstract class Schiff {
    private int schiffsNummer;
    private double statusSchiffshaut;
    private static int schiffsnummernkreisStart= 1;
    private int anzahlAnstriche;
    
    public Schiff() {
        schiffsNummer = schiffsnummernkreisStart++;
        statusSchiffshaut = 1;
        anzahlAnstriche = 0;
    }
    abstract public double preis();

    public void zustandAusgabe() {
        InOut.printString("Das Schiff " + schiffsNummer + " ist ein " + schiffsArt() + " und es sind " + statusSchiffshaut * 100 +
                "% Schiffshaut intakt");
    }
    public abstract String schiffsArt();

    public abstract double monatsGewinn();

    public boolean schadhaft() {
        return statusSchiffshaut < Definitions.MINDESTINTAKTSCHIFFSHAUT;
    }
    public double getStatusSchiffshaut() {
        return statusSchiffshaut;
    }
    public void neuerAnstrich() {
        if(anzahlAnstriche < 3) {
            anzahlAnstriche++;
            statusSchiffshaut = 1-(anzahlAnstriche * 0.05);
        }else {
            InOut.printString("Das Schiff wurde schon 3x gestrichen!");
        }
    }
    public int getNummer() {
        return schiffsNummer;
    }
    public double schadensPreis() {
        return 5 * preis();
    }
    public double SchrottPreis() {
        return preis() * 0.1;
    }

    public void nutztSichAbMonatlich() {
        statusSchiffshaut *= Definitions.ABNUTZUNGSFAKTOR;
    }
}
