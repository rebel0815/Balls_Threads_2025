package bankomat.model;

import bankomat.grafics.BankomatView;
import static bankomat.model.BankomatState.*;

public class BankomatModelImplementation implements BankomatModel {

	// state Variables
	private BankomatView theView;
	private BankomatState theState;

	// for Reporting
	private int currentEdge;
	private BankomatState nextState;
	private int code;
	private int betrag;
	private static final int korrekterCode= 1234;

	public void setView(BankomatView view) {
		theView = view;
		theState = START;
		code = 0;
		betrag = 0;
		theView.setText("Willkommen beim Bankomaten!");
		theView.setGeldladeText("");
		theView.setKartenButtonLabel("Karte rein");
		theView.setKartenText("Leer");
	}

	public void pressButtonDigit(int digit) {
		switch(theState){
			case DIG0 -> {
				theView.setText("Code: *");
				code=digit;
				traverseTo(DIG1,2);
			}
			case DIG1 -> {
				theView.setText("Code: **");
				code=10 * code + digit;
				traverseTo(DIG2,3);
			}
			case DIG2 -> {
				theView.setText("Code: ***");
				code=10 * code + digit;
				traverseTo(DIG3,4);
			}
			case DIG3 -> {
				theView.setText("Code: ****");
				code=10 * code + digit;
				traverseTo(DIG4,5);
			}
			case MON1 -> {
				betrag = betrag * 10 + digit;
				theView.setText("Betrag: " + betrag);
			}
			default -> {
				theView.setText("Ungültiger Zustand für Zifferneingabe: " + theState);
			}
		}
	}

	private void debugEdge(int edgeNumber, BankomatState theState) {
		System.out.println("Traversing Edge " + edgeNumber + " from state " + theState + " to state " + nextState );
	}

	private void traverseTo(BankomatState nextState, int edgeNumber) {
		System.out.println("Traversing Edge " + edgeNumber + " from state " + theState + " to state " + nextState );
		this.theState = nextState;
	}

	private void edge(int cEdge) {
		currentEdge = cEdge;
	}

	private void target(BankomatState nState) {
		nextState = nState;
	}

	private void traverse() {
		System.out.println("Traversing Edge " + currentEdge + " from state " + theState + " to state " + nextState );
		theState = nextState;
	}

	public void pressButtonCancel() {
		theView.setText("Cancel pressed.");
		switch (theState) {
			case DIG0 -> {
				traverseTo(CANCCARD,7);
			}
			case DIG1 -> {
				traverseTo(CANCCARD, 8);
			}
			case DIG2 -> {
				traverseTo(CANCCARD, 9);
			}
			case DIG3 -> {
				traverseTo(CANCCARD, 10);
			}
			case DIG4 -> {
				traverseTo(CANCCARD, 11);
			}
			case MON1 -> {
				traverseTo(CANCCARD, 13);
			}
			case MON2 -> {
				traverseTo(CANCCARD, 14);
			}
		}
	}

	public void pressButtonDelete() {
		theView.setText("Delete pressed.");
		switch(theState){
			case DIG1 -> {
				theView.setText("Code:");
				code=0;
				traverseTo(DIG0, 21);
			}
			case DIG2 -> {
				theView.setText("Code: *");
				code= code / 10;
				traverseTo(DIG1, 22);
			}
			case DIG3 -> {
				theView.setText("Code: **");
				code= code / 10;
				traverseTo(DIG2, 23);
			}
			case DIG4 -> {
				theView.setText("Code: ***");
				code= code / 10;
				traverseTo(DIG3, 24);
			}
		}
	}

	public void pressButtonEnter() {
		theView.setText("Enter pressed.");
		switch(theState){
			case DIG4 -> {
				if (code == korrekterCode) {
					theView.setText("Bitte Betrag eingeben!");
					traverseTo(MON1,12);
				}else {
					theView.setText("Der Code ist falsch, Try again!");
					traverseTo(DIG0,12);
				}
			}
		}
	}

	public void pressButtonMoney() {
		if (theState == MON1) {
			// Hier könnte man den bereits eingegebenen Betrag verarbeiten
			if (betrag > 0) {

				theView.setText("Bitte warten, Geld wird ausgezahlt: " + betrag);

				traverseTo(MONOUT, 15);
			} else {
				theView.setText("Bitte Betrag eingeben!");
			}
		} else {
			theView.setText("Geld kann nicht abgehoben werden!");
		}
	}

	public void pressButtonCard() {
		switch(theState) {
			case START -> {
				theView.setKartenButtonLabel("");
				theView.setText("Code: ");
				theView.setKartenText("Karte eingeschoben!");
				traverseTo(DIG0,1);
			}
			case CANCCARD -> {
				// Übergang zum Zustand CARDOUT, der die Karte ausgibt.
				theView.setText("Karte entnehmen!");
				traverseTo(BankomatState.CARDOUT, 16);
			}
			case CARDOUT -> {
				// Beispiel: Nach dem Entnehmen der Karte soll der Zustand zurück auf START wechseln.
				theView.setText("Karte wurde entnommen. Willkommen!");
				traverseTo(BankomatState.START, 17);
			}
			default -> {
				theView.setText("Ungültiger Zustand für Kartenaktion: " + theState);
			}

		}
	}

}


