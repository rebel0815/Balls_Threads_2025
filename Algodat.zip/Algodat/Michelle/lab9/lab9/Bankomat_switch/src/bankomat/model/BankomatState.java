package bankomat.model;

public enum BankomatState {
	START, DIG0, DIG1, DIG2, DIG3, DIG4, MON1, MON2, CARDOUT, MONOUT, CANCCARD;
}
