package bankomat;

import bankomat.grafics.BankomatMainFrame;
import bankomat.model.BankomatModelImplementation;

public class BankomatMain {

	
	public static void main(String[] args) {
		
		BankomatModelImplementation bankomatModel = new BankomatModelImplementation();
		BankomatMainFrame window = new BankomatMainFrame(bankomatModel);
		bankomatModel.setView(window);
		window.runFrame();

		
	}
	

}
