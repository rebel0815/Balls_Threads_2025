package bankomat.actions;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;
public class Edge20Action extends BankomatAction {
    public Edge20Action() {}
    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        contents.addAmount(parameter);
        theView.setText("Betrag: " + contents.getAmount());
    }
}

