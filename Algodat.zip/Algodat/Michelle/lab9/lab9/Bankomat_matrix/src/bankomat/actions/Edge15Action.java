package bankomat.actions;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;
public class Edge15Action extends BankomatAction {
    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
       contents.undoAmount(parameter);
       theView.setText("Betrag: " + contents.getAmount());

    }
}

