package bankomat.actions;

import bankomat.actions.BankomatAction;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;

public class CancelAction extends BankomatAction {

    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        theView.setText("Cancelled! Bitte Karte entnehmen!");
        contents.reset();
        theView.setKartenText("Karte zu sehen");
        theView.setKartenText("Karte entnehmen!");
    }

}
