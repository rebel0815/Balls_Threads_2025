package bankomat.semantics;

public class BankomatSemantics {
    private int theValue;
    private int theAmount;

    public BankomatSemantics() {

        theValue = 0;
        theAmount = 0;
    }

    public void reset() {

        theValue = 0;
        theAmount = 0;
    }

    public void addDigit(int parameter) {
        theValue = 10 * theValue + parameter;
    }

    public boolean codeIsCorrect() {
        return theValue == 1234;
    }

    public void chompDigit() {
        theValue = theValue / 10;
    }

    public void addAmount(int parameter) {
        theAmount = 10 * theAmount + parameter;
    }

    public int getAmount() {
        return theAmount;
    }

    public void undoAmount(int parameter) {
        theAmount = theAmount / 10;
    }

    public int debugCode() {
        return theValue;
    }
}
