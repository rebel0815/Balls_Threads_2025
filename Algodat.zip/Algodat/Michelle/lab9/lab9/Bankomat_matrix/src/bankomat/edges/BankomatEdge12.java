package bankomat.edges;
import bankomat.actions.BankomatAction;
import bankomat.actions.Edge12Action;
import bankomat.automaton.BankomatState;
import bankomat.semantics.BankomatSemantics;
public class BankomatEdge12 extends BankomatEdge{

    public BankomatEdge12() {
        super(12, null, null);
    }

    public BankomatState getNextState(BankomatSemantics x) {
        if (x.codeIsCorrect()) {
            return BankomatState.MON1;
        }else {
            return BankomatState.DIG0;
        }
    }

    public BankomatAction getAction() {
        return new Edge12Action();
    }

}
