package bankomat.automaton;

import bankomat.actions.CancelAction;
import bankomat.actions.*;
import bankomat.edges.*;

import static bankomat.automaton.BankomatEvent.*;
import static bankomat.automaton.BankomatState.*;

public class BankomatMatrix {
    private final BankomatEdge[][] automatonEdgeMatrix = new BankomatEdge[BankomatState.values().length][BankomatEvent.values().length];
    public BankomatMatrix() {
        resetMatrix();
        defineMatrix();
    }
    private void resetMatrix() {
        for (BankomatState x: BankomatState.values())
            for (BankomatEvent y: BankomatEvent.values()) {
                automatonEdgeMatrix[x.ordinal()][y.ordinal()] = null;
            }
    }

    ////////////////////////////////////////////////////////////////////
    //////////////// PUT YOUR AUTOMATON HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!
    ////// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv ////////////
    private void defineMatrix() {
        // putEdge(edgeNumber, from, event, to, action )
        // Karte reinstecken
        putEdge(START, CARD,  new BankomatEdge(1, DIG0, new Edge1Action()) );
        // Pin Eingabe: Jeder Tastendruck führt zum nächsten Zustand
        putEdge(DIG0, DIGIT,  new BankomatEdge(2, DIG1, new Edge2Action()) );
        putEdge(DIG1, DIGIT,  new BankomatEdge(3, DIG2, new Edge3Action()) );
        putEdge(DIG2, DIGIT,  new BankomatEdge(4, DIG3, new Edge4Action()) );
        putEdge(DIG3, DIGIT,  new BankomatEdge(5, DIG4, new Edge5Action()) );
        putEdge(DIG4, ENTER,  new BankomatEdge12());

        //Löschen der Ziffern
        putEdge(DIG1, DELETE,  new BankomatEdge(21, DIG0, new Edge21Action()) );
        putEdge(DIG2, DELETE,  new BankomatEdge(22, DIG1, new Edge22Action()) );
        putEdge(DIG3, DELETE,  new BankomatEdge(23, DIG2, new Edge23Action()) );
        putEdge(DIG4, DELETE,  new BankomatEdge(24, DIG3, new Edge24Action()) );

        // Geldbetragseintrage
        putEdge(MON1, DIGIT,  new BankomatEdge(19, MON2, new Edge19Action()) );
        putEdge(MON2, DIGIT,  new BankomatEdge(20, MON2, new Edge20Action()) );
        putEdge(MON2, DIGIT,  new BankomatEdge(15, MON2, new Edge15Action()) );
        putEdge(MON2, ENTER,  new BankomatEdge(16, CARDOUT, new Edge16Action()) );

        //Karten- und Geldausgabe
        putEdge(CARDOUT, CARD,  new BankomatEdge(17, MONOUT, new Edge17Action()) );
        putEdge(MONOUT, MONEY,  new BankomatEdge(18, START, new Edge18Action()) );

        //Abbruch
        putEdge(DIG0, CANCEL,  new BankomatEdge(7, CANCCARD, new CancelAction()) );
        putEdge(DIG1, CANCEL,  new BankomatEdge(8, CANCCARD, new CancelAction()) );
        putEdge(DIG2, CANCEL,  new BankomatEdge(9, CANCCARD, new CancelAction()) );
        putEdge(DIG3, CANCEL,  new BankomatEdge(10, CANCCARD, new CancelAction()) );
        putEdge(DIG4, CANCEL,  new BankomatEdge(11, CANCCARD, new CancelAction()) );
        putEdge(MON1, CANCEL,  new BankomatEdge(13, CANCCARD, new CancelAction()) );
        putEdge(MON2, CANCEL,  new BankomatEdge(14, CANCCARD, new CancelAction()) );

        // Rückkehr zum Startzustand nach Rückgabe
        putEdge(CANCCARD, CARD,  new BankomatEdge(6, START, new Edge6Action()) );




   }
   /////// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ /////////
   ///////////////////////////////////////////////////////////////////

    private void putEdge(BankomatState state, BankomatEvent event, BankomatEdge edge){
        if ( automatonEdgeMatrix[state.ordinal()][event.ordinal()] != null) {
            System.out.println("WARNING: Overwriting existing edge at " + state + ", " + event );
        }
        automatonEdgeMatrix[state.ordinal()][event.ordinal()] = edge;
    }

    public BankomatEdge getEdge(BankomatState state, BankomatEvent event) {
        return automatonEdgeMatrix[state.ordinal()][event.ordinal()];
    }
}
