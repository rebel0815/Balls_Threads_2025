package bankomat.actions;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;
public class Edge12Action extends BankomatAction {
    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        if(contents.codeIsCorrect()) {
            theView.setText("Korrekter Code, geben Sie den Betrag ein!");
        }else {
            theView.setText("Falscher Code, Try again!");
            contents.reset();
        }
    }
}

