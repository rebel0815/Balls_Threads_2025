package bankomat.actions;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;
public class Edge16Action extends BankomatAction {
    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        theView.setText("Bitte Karte entnehmen!");
        theView.setKartenText("Karte sichtbar!");
        theView.setKartenButtonLabel("Bitte Karte entfernen");
    }
}

