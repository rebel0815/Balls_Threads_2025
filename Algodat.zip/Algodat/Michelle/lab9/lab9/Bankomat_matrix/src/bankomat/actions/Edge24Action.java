package bankomat.actions;

import bankomat.actions.BankomatAction;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;

public class Edge24Action extends BankomatAction {

    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        theView.setText("Code **");
        contents.chompDigit();
    }

}
