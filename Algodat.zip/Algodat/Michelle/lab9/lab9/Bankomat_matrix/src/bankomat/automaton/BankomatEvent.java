package bankomat.automaton;

public enum BankomatEvent {
    DIGIT,
    ENTER,
    DELETE, MONEY, CARD, CANCEL
}
