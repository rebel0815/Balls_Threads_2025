package bankomat.actions;
import bankomat.grafics.BankomatView;
import bankomat.semantics.BankomatSemantics;
public class Edge6Action extends BankomatAction {
    public void execute(BankomatSemantics contents, BankomatView theView, int parameter) {
        theView.setGeldladeText("");
        theView.setText("Willkommen beim Bankomaten!");
        theView.setText("Bitte Karte einlegen");
        theView.setText("Kartenschacht leer");
    }
}

