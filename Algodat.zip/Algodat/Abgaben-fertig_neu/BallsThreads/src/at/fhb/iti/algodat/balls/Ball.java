package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBall;
import at.fhb.iti.algodat.balls.defs.Definitions;
import at.fhb.iti.algodat.balls.grafics.BallsPanel;

public class Ball extends BasicBall implements Runnable {

	private BallRectangle theRectangle;
	private Thread theThread;
	public boolean shallRun = true;

	public Ball(BallsPanel ballsPanel, BallRectangle br) {
		super(ballsPanel);
		theRectangle = br;

		// TODO Make the balls fly
		BallsStart();

	}
	public void BallsStart() {
		new Thread(this).start(); }

	/*public void step() {
		try {Thread.sleep(25); } catch (InterruptedException e)  {}
		move();
	}*/

	public void run() {
		while (shallRun) {
		// TODO rework run()
		while (!isTouching(theRectangle) && shallRun) {
			delay();
			move();
		}
		theRectangle.occupy();

		while (isTouching(theRectangle) && shallRun) {
			delay();
			move();
		}
		theRectangle.free();
			}
	}

	public void stop() {
		// TODO stop()
		shallRun = false;
	}

	private void delay() {
		try { Thread.sleep(Definitions.DELAY ); } catch (InterruptedException e) {}
	}

}
