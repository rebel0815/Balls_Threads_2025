package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBallRectangle;

public class BallRectangle extends BasicBallRectangle {

	// TODO fields
	private int ballsinRectangle;
	private int ticket;

	public BallRectangle(int d, int e, int f, int g) {

		super(d,e,f,g);
		ballsinRectangle = 0;
	}

	public synchronized void occupy() {
		// TODO occupy()
		while (ballsinRectangle >=3) {
			try {
				wait();
			}
			catch (InterruptedException e) {}
		}
		ballsinRectangle ++;
	}

	public synchronized void free() {
		// TODO free()
		if(ballsinRectangle > 0)
			ballsinRectangle --;
		notify();
	}


}
