package schiffe;

import definitions.Definitions;

public class Passagierschiff extends Schiff {
@Override
    public double preis() {
        return Definitions.PASSAGIERSCHIFFPREIS;
    }
@Override
    protected String schiffsArt() {
        return "Passagierschiff";
    }

    @Override
    public double betrag() {
        return 150;
    }

    @Override
    public double monatsGewinn() {
        return Definitions.PASSAGIERSCHIFFGEWINN;
    }
@Override
    public double anstrichsPreis() {
        return Definitions.PASSAGIERSCHIFFANSTRICHSPREIS;
    }


}
