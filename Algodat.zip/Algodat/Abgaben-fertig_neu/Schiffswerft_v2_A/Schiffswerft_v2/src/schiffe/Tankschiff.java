package schiffe;

import definitions.Definitions;


public class Tankschiff extends Schiff {

@Override
    public double preis() {
        return Definitions.TANKSCHIFFPREIS;
    }
@Override
    protected String schiffsArt() {
        return "Tankschiff";
    }

    @Override
    public double betrag() {
        return 70;
    }

    @Override
    public double monatsGewinn() {
        return Definitions.TANKSCHIFFGEWINN;
    }
@Override
    public double anstrichsPreis() {
        return Definitions.TANKSCHIFFANSTRICHSPREIS;
    }

}
