package schiffe;

import definitions.Definitions;

public abstract class Schiff {

    private static int naechsteFreieSchiffsNUmmer = 1;
    private int schiffsNummer;
    private double rostfaktor;
    private int streichAnzahl;
    private double schiffzustand;

    public Schiff() {
        this.schiffsNummer = naechsteFreieSchiffsNUmmer++;
        this.rostfaktor = 1.0;
        this.streichAnzahl = 0;
        this.schiffzustand = 1.0; // Anfangszustand des Schiffes
    }

    public abstract double preis();

    public abstract double monatsGewinn();

    public void rostet() {
        this.schiffzustand *= Definitions.ROSTFAKTORPROMONAT;
        if (this.schiffzustand < Definitions.MINIMALERROSTFAKTOR) {
            this.schiffzustand = Definitions.MINIMALERROSTFAKTOR; // Verhindern, dass der Zustand unter den minimalen Wert fällt
        }
    }

    public boolean gesunken() {
        return rostfaktor < Definitions.MINIMALERROSTFAKTOR;
    }

    public double bergungsKosten() {
        return 5 * preis();
    }

    public void anstreichen() {
        if(this.streichAnzahl < Definitions.MAXIMALESTREICHANZAHL) {
            this.schiffzustand = 1.0; // Schiff wird auf den besten Zustand zurückgesetzt
            this.streichAnzahl++;
        }
    }

    public abstract double anstrichsPreis();

    public double verschrottungsPreis() {
        return 0.1 * preis();
    }

    public void zustandAusgeben() {
        System.out.println(
                "Schiff " + schiffsNummer +
                        " ist ein " + schiffsArt() +
                        " Rostfaktor: " + rostfaktor +
                        " wurde schon " + streichAnzahl + " gestrichen"
        );
    }

    protected abstract String schiffsArt();

    // Getter-Methoden
    public int getSchiffsNummer() {
        return this.schiffsNummer;
    }

    public double getRostfaktor() {
        return this.rostfaktor;
    }

    public int getStreichAnzahl() {
        return this.streichAnzahl;
    }

    public double getSchiffzustand() {
        return this.schiffzustand;
    }

    public abstract double betrag();
}
