package schiffe;

import definitions.Definitions;

public class Frachtschiff extends Schiff {
@Override
    public double preis() {
        return Definitions.FRACHTSCHIFFPREIS;
    }
@Override
    protected String schiffsArt() {
        return "Frachtschiff";
    }

    @Override
    public double betrag() {
        return 30;
    }

    @Override
    public double monatsGewinn() {
        return Definitions.FRACHTSCHIFFGEWINN;
    }
@Override
    public double anstrichsPreis() {
        return Definitions.FRACHTSCHIFFANSTRICHSPREIS;
    }

}
