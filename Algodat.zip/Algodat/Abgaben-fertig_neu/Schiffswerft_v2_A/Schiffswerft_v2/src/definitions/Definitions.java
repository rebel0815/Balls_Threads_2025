package definitions;

public class Definitions {

    public static final double ANFANGSKASSASTAND = 500;
    public static final int MAXIMALESTREICHANZAHL = 3;
    public static final double ROSTFAKTORPROMONAT = 0.92;
    public static final double MINIMALERROSTFAKTOR = 0.25;

    public static final double TANKSCHIFFPREIS = 70;
    public static final double TANKSCHIFFGEWINN = 0.5;
    public static final double TANKSCHIFFANSTRICHSPREIS = 3;

    public static final double FRACHTSCHIFFPREIS = 30; // in Mio Euro
    public static final double FRACHTSCHIFFGEWINN = 0.2;
    public static final double FRACHTSCHIFFANSTRICHSPREIS = 1;

    public static final double PASSAGIERSCHIFFPREIS = 150;
    public static final double PASSAGIERSCHIFFGEWINN = 1;
    public static final double PASSAGIERSCHIFFANSTRICHSPREIS = 5;

}
