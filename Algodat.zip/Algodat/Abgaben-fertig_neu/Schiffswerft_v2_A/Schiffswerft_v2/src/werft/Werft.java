package werft;

import schiffe.Schiff;
import spiel.KonkursException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Werft {
    private List<Schiff> dieSchiffe;
    private Kassa dieKassa;

    public Werft() {
        dieSchiffe = new ArrayList<>();
        dieKassa = new Kassa();
    }

    public void arbeitetEinenMonat() throws KonkursException {
        schiffeVerdienen();
        schiffeSinken();
    }

    private void schiffeSinken() throws KonkursException {
        Iterator<Schiff> iterator = dieSchiffe.iterator();
        while (iterator.hasNext()) {
            Schiff schiff = iterator.next();
            if (schiff.gesunken()) {
                dieKassa.bezahlen(schiff.bergungsKosten());
                iterator.remove();
            }
        }
    }

    private void schiffeVerdienen() throws KonkursException {
        for (Schiff schiff : dieSchiffe) {

                dieKassa.gewinn(schiff.monatsGewinn());
           }
    }

    public void lackiereSchiff(int schiffnummer) throws KonkursException {
        for (Schiff schiff : dieSchiffe) {
            if (schiff.getSchiffsNummer() == schiffnummer) {
                schiff.anstreichen();
                dieKassa.bezahlen(schiff.anstrichsPreis());
                break;
            }
        }
    }

    public void zustandAusgeben() {
        dieKassa.zustandAusgeben();
        for (Schiff schiff : dieSchiffe) {
            schiff.zustandAusgeben();
        }
    }

    public void bezahlen(double betrag) throws KonkursException {
        dieKassa.bezahlen(betrag);
    }

    public void add(Schiff schiff) {
        dieSchiffe.add(schiff);
    }

    public void schrotten(int schiffnummer) throws KonkursException {
        Iterator<Schiff> iterator = dieSchiffe.iterator();
        while (iterator.hasNext()) {
            Schiff schiff = iterator.next();
            if (schiff.getSchiffsNummer() == schiffnummer) {
                dieKassa.bezahlen(schiff.verschrottungsPreis());
                iterator.remove();
                break;
            }
        }
    }

    // TODO Weitere Methoden der Werft
}
