package werft;

import definitions.Definitions;
import spiel.KonkursException;

public class Kassa {

    private double kassaStand; //in Mio EUR

    public Kassa() {
        kassaStand = Definitions.ANFANGSKASSASTAND;
    }

    public void zustandAusgeben() {
        System.out.println("Kassastand: " + kassaStand);
    }

    public void bezahlen(double ausgabe) throws KonkursException {
        kassaStand = kassaStand - ausgabe;
        if(kassaStand < 0 ) throw new KonkursException();
    }

    public void gewinn(double einnahme) {
        kassaStand = kassaStand + einnahme;
    }

}