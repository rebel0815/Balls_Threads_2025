package spiel;

public class KonkursException extends Exception {
}
