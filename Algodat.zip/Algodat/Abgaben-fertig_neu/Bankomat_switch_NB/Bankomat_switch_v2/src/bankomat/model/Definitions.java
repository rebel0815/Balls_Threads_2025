package bankomat.model;

public class Definitions {
    public static final int CORRECTCODE = 1234;
}
