package bankomat.model;

import bankomat.grafics.BankomatView;

import java.awt.print.Book;

import static bankomat.model.BankomatState.*;

public class BankomatModelImplementation implements BankomatModel {

	// state Variables
	private BankomatView theView;
	private BankomatState theState;

	// for Reporting
	private int currentEdge;
	private BankomatState nextState;
	private int theCode;
	private int theAmount;
	private int theLimit;

	public void setView(BankomatView view) {
		theView = view;
		theState = START;
		theCode = 0;
		theAmount = 0;
		theLimit = 1500;
	}

	public void pressButtonDigit(int digit) {
		// TODO Auto-generated method stub
//		theView.setText("Digit " + digit + " pressed.");

		switch (theState) {
			case DIG0 -> {
				BankomatState nextState = DIG1;
				theView.setText("*");
				theCode = digit;
				debugEdge(2, theState, nextState);
				theState = nextState;
			}
			case DIG1 -> {
				BankomatState nextState = DIG2;
				theView.setText("**");
				theCode = theCode * 10 + digit;
				debugEdge(3, theState, nextState);
				theState = nextState;
			}
			case DIG2 -> {
				BankomatState nextState = DIG3;
				theView.setText("***");
				theCode = theCode * 10 + digit;
				debugEdge(4, theState, nextState);
				theState = nextState;
			}
			case DIG3 -> {
				BankomatState nextState = DIG4;
				theView.setText("****");
				theCode = theCode * 10 + digit;
				debugEdge(5, theState, nextState);
				theState = nextState;
			}
			case CR -> {
				BankomatState nextState = MON;
				if ( digit > 0 ) {
					theAmount = theAmount + digit;
					theView.setText("EUR " + theAmount);
					debugEdge(19, theState, nextState);
					theState = nextState;
				} else {
					theView.setText("Bitte einen gültigen Betrag eingeben");
				}
			}
			case MON -> {
				BankomatState nextState = MON;
				theAmount = theAmount * 10 + digit;
				theView.setText("EUR " + theAmount);
				debugEdge(20, theState, nextState);
				theState = nextState;
			}
		}
	}

	private void debugEdge(int edgeNumber, BankomatState theState, BankomatState nextState) {
		System.out.println("Traversing Edge " + edgeNumber + " from state " + theState + " to state " + nextState);
	}

	private void traverseTo(BankomatState nextState, int edgeNumber) {
		System.out.println("Traversing Edge " + edgeNumber + " from state " + theState + " to state " + nextState);
		this.theState = nextState;
	}

	private void edge(int cEdge) {
		currentEdge = cEdge;
	}

	private void target(BankomatState nState) {
		nextState = nState;
	}

	private void traverse() {
		System.out.println("Traversing Edge " + currentEdge + " from state " + theState + " to state " + nextState);
		theState = nextState;
	}

	public void pressButtonCancel() {
		switch (theState) {
			case DIG0 -> {
				BankomatState nextState = CAN;
				debugEdge(11, theState, nextState);
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case DIG1 -> {
				BankomatState nextState = CAN;
				debugEdge(12, theState, nextState);
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case DIG2 -> {
				BankomatState nextState = CAN;
				debugEdge(13, theState, nextState);
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case DIG3 -> {
				BankomatState nextState = CAN;
				debugEdge(14, theState, nextState);
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case DIG4 -> {
				BankomatState nextState = CAN;
				debugEdge(15, theState, nextState);
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case CR -> {
				BankomatState nextState = CAN;
				debugEdge(17, theState, nextState);
				if ( theAmount != 0 ) {
					theAmount = 0;
				}
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
			case MON -> {
				BankomatState nextState = CAN;
				debugEdge(18, theState, nextState);
				if ( theAmount != 0 ) {
					theAmount = 0;
				}
				theView.setText("Transaktion abgebrochen. Bitte Karte entnehmen!");
				//theView.setKartenText("Karte entnommen!");
				theView.setKartenButtonLabel("Karte entnehmen!");
				theState = nextState;
			}
		}
	}

	public void pressButtonDelete() {
		// TODO Auto-generated method stub
//		theView.setText("Delete pressed.");
		switch (theState) {
			case DIG1 -> {
				BankomatState nextState = DIG0;
				theCode = theCode / 10;
				debugEdge(6, theState, nextState);
				theState = nextState;
				theView.setText("");
			}
			case DIG2 -> {
				BankomatState nextState = DIG1;
				theCode = theCode / 10;
				debugEdge(7, theState, nextState);
				theState = nextState;
				theView.setText("*");
			}
			case DIG3 -> {
				BankomatState nextState = DIG2;
				theCode = theCode / 10;
				debugEdge(8, theState, nextState);
				theState = nextState;
				theView.setText("**");
			}
			case DIG4 -> {
				BankomatState nextState = DIG3;
				theCode = theCode / 10;
				debugEdge(9, theState, nextState);
				theState = nextState;
				theView.setText("***");
			}
			case MON -> {
				BankomatState nextState = MON;
				if ( theAmount > 10 ) {
					theAmount = theAmount / 10;
					theView.setText("EUR " + theAmount);
				} else {
					theAmount = 0;
//					theView.setText("Withdraw " + theAmount + "$ ?");
					theView.setText("Betrag eingeben: ");
				}
				debugEdge(21, theState, nextState);
				theState = nextState;
			}
		}
	}

	public void pressButtonEnter() {
//		theView.setText("Enter pressed.");
		switch (theState) {
			case DIG4 -> {
				if (theCode == Definitions.CORRECTCODE) {
					BankomatState nextState = CR;
					debugEdge(16, theState, nextState);
					theState = nextState;
					theView.setText("PIN akzeptiert. Max. behebbarer Betrag EUR 1.500,--");
				} else {
					BankomatState nextState = CAN;
					debugEdge(16, theState, nextState);
					theView.setText("PIN inkorrekt.");
					theView.setKartenText("Bitte entnehmen Sie Ihre Karte");
					theView.setKartenButtonLabel("Karte entnehmen");
					theState = nextState;
				}
			}
			case MON -> {
				// This part is unnecessary for the task. Keep it or remove the if clause
				if ( theAmount <= theLimit ) {
					BankomatState nextState = BOOK;
					debugEdge(22, theState, nextState);
					theView.setText("Bitte entnehmen Sie Ihre Karte.");
					theView.setKartenText("Karte entnehmen.");
					theView.setKartenButtonLabel("Karte entnehmen.");
					theView.setGeldladeText("EUR " + theAmount);
					theState = nextState;
				} else {
					theView.setText("Limit überschritten. Max. behebbarer Betrag " + theLimit + " EUR");
					theAmount = 0;
					BankomatState nextState = CR;
					debugEdge(25, theState, nextState);
					theState = nextState;
				}
			}
		}
	}

	public void pressButtonMoney() {
		switch (theState) {
			case MONOUT -> {
				BankomatState nextState = START;
				theView.setText("Willkommen beim Bankomaten!");
				theView.setKartenText("Kartenschacht leer");
				theView.setKartenButtonLabel("Karte einlegen");
				theView.setGeldladeText("Geldlade leer");
				debugEdge(24, theState, nextState);
				theState = nextState;
				theAmount = 0;
			}
		}
	}

	public void pressButtonCard() {
		switch (theState) {
			// STYLE 1
			case START -> {
				theView.setText("Bitte PIN eingeben");
				theView.setKartenText("Karte im Bankomaten!");
				theView.setKartenButtonLabel("Karte eingelegt!");
				BankomatState nextState = DIG0;
				debugEdge(1, theState, nextState);
				theState = nextState;
			}
			case CAN -> {
				BankomatState nextState = START;
				debugEdge(10, theState, nextState);
				theView.setText("Willkommen beim Bankomaten!");
				theView.setKartenText("Kartenschacht leer");
				theView.setKartenButtonLabel("Karte einlegen");
				theState = nextState;
			}
			case BOOK -> {
				BankomatState nextState = MONOUT;
				debugEdge(23, theState, nextState);
				theView.setText("Bitte vergessen Sie nicht das Geld zu entnehmen!");
				theView.setKartenText("Kartenschacht leer");
				theView.setKartenButtonLabel("Karte einlegen");
				theView.setGeldladeText("EUR " + theAmount);
				theState = nextState;
			}

		}
	}
}


