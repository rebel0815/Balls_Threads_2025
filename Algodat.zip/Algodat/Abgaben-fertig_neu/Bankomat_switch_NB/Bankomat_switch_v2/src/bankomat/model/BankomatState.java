package bankomat.model;

public enum BankomatState {
	// TODO Rename States
	START,
	CAN,
	CR,
	DIG0,
	DIG1,
	DIG2,
	DIG3,
	DIG4,
	MON,
	BOOK,
	MONOUT;
}
